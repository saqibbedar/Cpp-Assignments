/*
    1. (Practice) Write a for statement for each of the following cases:
*/

#include <iostream>
using namespace std;

int main()
{
    // a. Use a counter named i that has an initial value of 1, a final value of 20, and an increment of 1.

    for (int i = 1; i <= 20; i++)
    {
        /*  Code */
    }
    
    // b. Use a counter named icount that has an initial value of 1, a final value of 20, and an increment of 2.

    for (int icount = 1; icount <= 20; icount += 2)
    {
        /*  Code */
    }
    
    // c. Use a counter named j that has an initial value of 1, a final value of 100, and an increment of 5.

    for (int j = 1; j <= 100; j+= 5)
    {
        /*  Code */
    }
    
    // d. Use a counter named icount that has an initial value of 20, a final value of 1, and an increment of -1.

    for (int icount = 20; icount <= 1; icount--)
    {
        /*  Code */
    }
    
    // e. Use a counter named icount that has an initial value of 20, a final value of 1, and an increment of -2.

    for (int icount = 20; icount <= 1; icount-= 2)
    {
        /*  Code */
    }

    // f. Use a counter named count that has an initial value of 1.0, a final value of 16.2, and an increment of 0.2.

    for (double count = 1.0; count <= 16.2; count += 0.2)
    {
        /*  Code */
    }

    // g. Use a counter named xcnt that has an initial value of 20.0, a final value of 10.0, and an increment of -0.5.

    for (double xcnt = 20.0; xcnt <= 10.0; xcnt += -0.5)
    {
        /*  Code */
    }

    return 0;
}